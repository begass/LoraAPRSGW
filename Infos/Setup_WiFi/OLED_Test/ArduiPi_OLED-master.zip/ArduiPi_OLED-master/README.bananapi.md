# Bananapi

Banana pi version requires `autogen.sh` before `make`.
